county: county name
log_radon: log radon level
floor: 0 basement, 1 first floor
