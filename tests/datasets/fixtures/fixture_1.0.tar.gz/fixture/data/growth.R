### Growth of four plants, in the style of base R's ChickWeight.R
"growth" <-
  structure(list(height = c(1.5, 2, NA, 3.25, -0.5, 4, 2.5, 1e-3),
    pot = c(1:3, 5:9), # one pot lost
    plant = ordered(rep.int(1:4, 2), levels = c(3, 1, 4, 2),
      labels = c("p3", "p1", "p4", "p2")),
    soil = factor(c(1, 2, 2, 1, NA, 2, 1, 2), levels = 1:2, labels = c("clay", "sand")),
    block = gl(2, 4), dose = factor(rep(c(10, 2), 4)), site = c(rep("a b", 7), NA)),
  row.names = 1:8, class = c("groupedData", "data.frame"),
  formula = height ~ pot | plant, outer = ~ soil, labels = list(y = "Height"))
environment(attr(growth, "formula")) <- emptyenv()
environment(attr(growth, "outer")) <- emptyenv()
